<?php
	error_reporting(E_ALL);
	ini_set('display_errors', 0);
	ini_set('log_errors', 1);
	ini_set('error_log', __DIR__ . '/php-error.log');

	define("DB_HOST", 'localhost');
	define("DB_USER", 'McJim');
	define("DB_PASS", 'Restricted654123');
	define("DB_NAME", 'inventory');
?>